var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_http = __toESM(require("http"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_ws = require("ws");
var import_vite = require("vite");
var serverRecharges = [];
var serverWithdrawals = [];
var serverCards = [];
var serverCommercialConfig = {
  adminBank: {
    bankName: process.env.BANK_NAME || "Banco de Venezuela (0102)",
    phone: process.env.BANK_PHONE || "0424-8653930",
    rif: process.env.BANK_RIF || "J-50769027-0",
    holderName: process.env.BANK_HOLDER_NAME || "Grupo Agro Cajigal S.A.",
    type: process.env.BANK_TYPE || "Pago M\xF3vil"
  },
  precio_carton_base_ves: 25,
  singleCardPriceVes: 25,
  cardPrices: {
    pack2: 50,
    pack4: 100,
    pack6: 150
  },
  exchangeRateVesUsd: 60,
  prizeMultipliers: {
    fullCard: 50,
    fourCorners: 8,
    lineHorizontal: 3,
    lineVertical: 3,
    lineDiagonal: 4
  },
  drawDrawTotalCount: 32,
  maxRiskPerRound: 5e4,
  closingBufferMinutes: 3,
  twoFactorOtpDemo: "123456"
};
var serverUsers = [];
var serverCredentials = [
  {
    id: "cred-1",
    displayName: "Director General",
    username: process.env.SUPER_ADMIN_USER || "admin",
    role: "Super Admin",
    status: "active",
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    password: process.env.SUPER_ADMIN_PASS || "admin123"
  },
  {
    id: "cred-2",
    displayName: "Auditor Principal",
    username: process.env.AUDITOR_USER || "auditor",
    role: "Auditor",
    status: "active",
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    password: process.env.AUDITOR_PASS || "auditor123"
  },
  {
    id: "cred-3",
    displayName: "Operador B\xF3veda Central",
    username: process.env.FINANZAS_USER || "finanzas",
    role: "Operador Financiero",
    status: "active",
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    password: process.env.FINANZAS_PASS || "finanzas123"
  }
];
var serverRounds = [
  {
    id: "round-101",
    roundNumber: 101,
    order: 1,
    title: "Sorteo Mediod\xEDa #101",
    openBetAt: new Date(Date.now() - 4 * 60 * 60 * 1e3).toISOString(),
    closeBetAt: new Date(Date.now() - 3 * 60 * 60 * 1e3).toISOString(),
    drawAt: new Date(Date.now() - 2 * 60 * 60 * 1e3).toISOString(),
    starts_at: new Date(Date.now() - 4 * 60 * 60 * 1e3).toISOString(),
    ends_at: new Date(Date.now() - 3 * 60 * 60 * 1e3).toISOString(),
    status: "finished",
    drawnFichas: [1, 5, 12, 19, 23, 26, 28, 30, 31, 35, 40, 44, 49, 51, 52, 55, 59, 60, 62, 65, 66, 67, 70, 2, 8, 14, 27, 33, 42, 53, 58, 69],
    totalCardsSold: 48,
    cardPriceVes: 25,
    card_price: 25,
    prize_percentage: 70,
    jackpotVes: 12500,
    winningCardsCount: 6,
    totalPrizesPaidVes: 2150,
    resultLocked: true,
    resultSubmittedBy: "Carlos Admin",
    resultSubmittedAt: new Date(Date.now() - 2 * 60 * 60 * 1e3).toISOString()
  },
  {
    id: "round-102",
    roundNumber: 102,
    order: 2,
    title: "Sorteo Estelar Tarde #102",
    openBetAt: new Date(Date.now() - 30 * 60 * 1e3).toISOString(),
    closeBetAt: new Date(Date.now() + 45 * 60 * 1e3).toISOString(),
    drawAt: new Date(Date.now() + 48 * 60 * 1e3).toISOString(),
    starts_at: new Date(Date.now() - 30 * 60 * 1e3).toISOString(),
    ends_at: new Date(Date.now() + 45 * 60 * 1e3).toISOString(),
    status: "open",
    drawnFichas: [],
    totalCardsSold: 36,
    cardPriceVes: 25,
    card_price: 25,
    prize_percentage: 70,
    jackpotVes: 15e3,
    winningCardsCount: 0,
    totalPrizesPaidVes: 0,
    resultLocked: false
  },
  {
    id: "round-103",
    roundNumber: 103,
    order: 3,
    title: "Gran Sorteo Nocturno #103",
    openBetAt: new Date(Date.now() + 60 * 60 * 1e3).toISOString(),
    closeBetAt: new Date(Date.now() + 3 * 60 * 60 * 1e3).toISOString(),
    drawAt: new Date(Date.now() + 3.5 * 60 * 60 * 1e3).toISOString(),
    starts_at: new Date(Date.now() + 60 * 60 * 1e3).toISOString(),
    ends_at: new Date(Date.now() + 3 * 60 * 60 * 1e3).toISOString(),
    status: "scheduled",
    drawnFichas: [],
    totalCardsSold: 0,
    cardPriceVes: 30,
    card_price: 30,
    prize_percentage: 75,
    jackpotVes: 25e3,
    winningCardsCount: 0,
    totalPrizesPaidVes: 0,
    resultLocked: false
  },
  {
    id: "round-104",
    roundNumber: 104,
    order: 4,
    title: "Sorteo Madrugada Millonario #104",
    openBetAt: new Date(Date.now() + 4 * 60 * 60 * 1e3).toISOString(),
    closeBetAt: new Date(Date.now() + 6 * 60 * 60 * 1e3).toISOString(),
    drawAt: new Date(Date.now() + 6.5 * 60 * 60 * 1e3).toISOString(),
    starts_at: new Date(Date.now() + 4 * 60 * 60 * 1e3).toISOString(),
    ends_at: new Date(Date.now() + 6 * 60 * 60 * 1e3).toISOString(),
    status: "scheduled",
    drawnFichas: [],
    totalCardsSold: 0,
    cardPriceVes: 20,
    card_price: 20,
    prize_percentage: 80,
    jackpotVes: 2e4,
    winningCardsCount: 0,
    totalPrizesPaidVes: 0,
    resultLocked: false
  }
];
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  const server = import_http.default.createServer(app);
  app.use(import_express.default.json({ limit: "50mb" }));
  app.use(import_express.default.urlencoded({ limit: "50mb", extended: true }));
  const wss = new import_ws.WebSocketServer({ server, path: "/ws" });
  const broadcastRealtimeEvent = (eventType, payload) => {
    const message = JSON.stringify({
      event: eventType,
      type: eventType,
      payload,
      timestamp: Date.now()
    });
    wss.clients.forEach((client) => {
      if (client.readyState === import_ws.WebSocket.OPEN) {
        try {
          client.send(message);
        } catch (err) {
          console.error("[WebSocket] Error broadcasting to client:", err);
        }
      }
    });
  };
  wss.on("connection", (ws) => {
    ws.send(
      JSON.stringify({
        event: "connected",
        type: "connected",
        timestamp: Date.now(),
        serverTime: Date.now()
      })
    );
    ws.on("message", (data) => {
      try {
        const msg = JSON.parse(data.toString());
        if (msg.type === "ping" || msg.event === "ping") {
          ws.send(JSON.stringify({ event: "pong", type: "pong", timestamp: Date.now() }));
        } else if (msg.type === "new_round_created" || msg.event === "new_round_created") {
          if (msg.round || msg.payload) {
            const roundData = msg.round || msg.payload?.round || msg.payload;
            if (roundData && roundData.id) {
              const existingIdx = serverRounds.findIndex((r) => r.id === roundData.id);
              if (existingIdx >= 0) {
                serverRounds[existingIdx] = { ...serverRounds[existingIdx], ...roundData };
              } else {
                serverRounds = [roundData, ...serverRounds];
              }
              broadcastRealtimeEvent("new_round_created", { round: roundData });
            }
          }
        } else if (msg.type === "sync_all_rounds" && Array.isArray(msg.rounds)) {
          const incomingIds = new Set(msg.rounds.map((r) => r.id));
          const keptExisting = serverRounds.filter((r) => !incomingIds.has(r.id));
          serverRounds = [...msg.rounds, ...keptExisting];
        } else if (msg.type === "recharge_submitted" || msg.type === "recharge_created" || msg.event === "recharge_submitted" || msg.event === "recharge_created" || msg.event === "postgres_changes") {
          const rechargeData = msg.recharge || msg.payload?.recharge || msg.new || msg.payload;
          if (rechargeData && rechargeData.id) {
            const existingIdx = serverRecharges.findIndex((r) => r.id === rechargeData.id);
            if (existingIdx >= 0) {
              serverRecharges[existingIdx] = { ...serverRecharges[existingIdx], ...rechargeData };
            } else {
              serverRecharges = [rechargeData, ...serverRecharges];
            }
            broadcastRealtimeEvent("postgres_changes", {
              event: existingIdx >= 0 ? "UPDATE" : "INSERT",
              schema: "public",
              table: "recharges",
              new: rechargeData,
              record: rechargeData,
              old: existingIdx >= 0 ? serverRecharges[existingIdx] : null
            });
            broadcastRealtimeEvent(existingIdx >= 0 ? "recharge_updated" : "recharge_created", {
              recharge: rechargeData
            });
          }
        } else if (msg.type === "withdrawal_submitted" || msg.type === "withdrawal_created" || msg.event === "withdrawal_submitted" || msg.event === "withdrawal_created" || msg.event === "postgres_changes" && (msg.table === "withdrawals" || msg.payload?.table === "withdrawals")) {
          const withdrawalData = msg.withdrawal || msg.payload?.withdrawal || msg.new || msg.payload?.new || msg.payload;
          if (withdrawalData && withdrawalData.id) {
            const existingIdx = serverWithdrawals.findIndex((w) => w.id === withdrawalData.id);
            if (existingIdx >= 0) {
              serverWithdrawals[existingIdx] = { ...serverWithdrawals[existingIdx], ...withdrawalData };
            } else {
              serverWithdrawals = [withdrawalData, ...serverWithdrawals];
            }
            broadcastRealtimeEvent("postgres_changes", {
              event: existingIdx >= 0 ? "UPDATE" : "INSERT",
              schema: "public",
              table: "withdrawals",
              new: withdrawalData,
              record: withdrawalData,
              old: existingIdx >= 0 ? serverWithdrawals[existingIdx] : null
            });
            broadcastRealtimeEvent(existingIdx >= 0 ? "withdrawal_updated" : "withdrawal_created", {
              withdrawal: withdrawalData
            });
          }
        } else if (msg.type === "user_registered" || msg.type === "player_registered" || msg.event === "user_registered" || msg.event === "player_registered") {
          const userData = msg.user || msg.player || msg.payload?.user || msg.payload;
          if (userData && (userData.id || userData.documentId || userData.cedula)) {
            const userId = userData.id || `usr-${Date.now()}`;
            const normalizedUser = {
              id: userId,
              name: userData.name || userData.nombre || "Usuario",
              documentId: (userData.documentId || userData.cedula || "").toUpperCase(),
              phone: userData.phone || userData.telefono || "0412-0000000",
              role: userData.role || "Player",
              status: userData.status || "active",
              availableBalance: userData.availableBalance || 0,
              pendingBalance: userData.pendingBalance || 0,
              lockedBalance: userData.lockedBalance || 0,
              totalWonVes: userData.totalWonVes || 0,
              createdAt: userData.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
              ...userData
            };
            const existingIdx = serverUsers.findIndex((u) => u.id === userId || u.documentId && u.documentId.toUpperCase() === normalizedUser.documentId);
            if (existingIdx >= 0) {
              serverUsers[existingIdx] = { ...serverUsers[existingIdx], ...normalizedUser };
            } else {
              serverUsers = [normalizedUser, ...serverUsers];
            }
            broadcastRealtimeEvent("postgres_changes", {
              event: existingIdx >= 0 ? "UPDATE" : "INSERT",
              schema: "public",
              table: "users",
              new: normalizedUser,
              record: normalizedUser
            });
            broadcastRealtimeEvent("user_registered", { user: normalizedUser });
            broadcastRealtimeEvent("player_registered", { player: normalizedUser });
          }
        } else if (msg.type === "sync_all_users" && Array.isArray(msg.users)) {
          const incomingIds = new Set(msg.users.map((u) => u.id));
          const kept = serverUsers.filter((u) => !incomingIds.has(u.id));
          serverUsers = [...msg.users, ...kept];
        } else if (msg.type === "commercial_config_updated" || msg.type === "update_commercial_config" || msg.event === "commercial_config_updated" || msg.event === "update_commercial_config") {
          const newCfg = msg.config || msg.payload?.config || msg.payload;
          if (newCfg) {
            serverCommercialConfig = {
              ...serverCommercialConfig,
              ...newCfg,
              adminBank: {
                ...serverCommercialConfig.adminBank,
                ...newCfg.adminBank || {}
              },
              cardPrices: {
                ...serverCommercialConfig.cardPrices,
                ...newCfg.cardPrices || {}
              },
              prizeMultipliers: {
                ...serverCommercialConfig.prizeMultipliers,
                ...newCfg.prizeMultipliers || {}
              }
            };
            broadcastRealtimeEvent("postgres_changes", {
              event: "UPDATE",
              schema: "public",
              table: "commercial_config",
              new: serverCommercialConfig,
              record: serverCommercialConfig
            });
            broadcastRealtimeEvent("commercial_config_updated", { config: serverCommercialConfig });
          }
        }
      } catch (err) {
        console.warn("[WebSocket] Error processing message:", err);
      }
    });
  });
  const handleGetCommercialConfig = (req, res) => {
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    res.setHeader("Surrogate-Control", "no-store");
    res.json({
      success: true,
      timestamp: Date.now(),
      data: serverCommercialConfig
    });
  };
  app.get("/api/commercial-config", handleGetCommercialConfig);
  app.get("/api/config", handleGetCommercialConfig);
  app.get("/api/config/comercial", handleGetCommercialConfig);
  app.get("/api/config/commercial", handleGetCommercialConfig);
  app.get("/api/comercial", handleGetCommercialConfig);
  const handleUpdateCommercialConfig = (req, res) => {
    const incoming = req.body;
    if (!incoming || typeof incoming !== "object") {
      return res.status(400).json({ success: false, message: "Par\xE1metros de configuraci\xF3n inv\xE1lidos" });
    }
    const basePrice = incoming.precio_carton_base_ves !== void 0 ? Number(incoming.precio_carton_base_ves) : incoming.singleCardPriceVes !== void 0 ? Number(incoming.singleCardPriceVes) : serverCommercialConfig.precio_carton_base_ves || 25;
    serverCommercialConfig = {
      ...serverCommercialConfig,
      ...incoming,
      precio_carton_base_ves: basePrice,
      singleCardPriceVes: basePrice,
      adminBank: {
        ...serverCommercialConfig.adminBank,
        ...incoming.adminBank || {}
      },
      cardPrices: {
        pack2: basePrice * 2,
        pack4: basePrice * 4,
        pack6: basePrice * 6,
        ...incoming.cardPrices || {}
      },
      prizeMultipliers: {
        ...serverCommercialConfig.prizeMultipliers,
        ...incoming.prizeMultipliers || {}
      }
    };
    broadcastRealtimeEvent("postgres_changes", {
      event: "UPDATE",
      schema: "public",
      table: "config/comercial",
      new: serverCommercialConfig,
      record: serverCommercialConfig
    });
    broadcastRealtimeEvent("postgres_changes", {
      event: "UPDATE",
      schema: "public",
      table: "commercial_config",
      new: serverCommercialConfig,
      record: serverCommercialConfig
    });
    broadcastRealtimeEvent("commercial_config_updated", {
      config: serverCommercialConfig
    });
    broadcastRealtimeEvent("config/comercial", {
      config: serverCommercialConfig,
      data: serverCommercialConfig
    });
    res.status(200).json({
      success: true,
      message: "Par\xE1metros comerciales y datos bancarios actualizados y sincronizados en tiempo real",
      data: serverCommercialConfig
    });
  };
  app.post("/api/commercial-config", handleUpdateCommercialConfig);
  app.put("/api/commercial-config", handleUpdateCommercialConfig);
  app.post("/api/config", handleUpdateCommercialConfig);
  app.post("/api/config/comercial", handleUpdateCommercialConfig);
  app.put("/api/config/comercial", handleUpdateCommercialConfig);
  app.post("/api/config/commercial", handleUpdateCommercialConfig);
  app.put("/api/config/commercial", handleUpdateCommercialConfig);
  app.post("/api/comercial", handleUpdateCommercialConfig);
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", serverTime: Date.now(), activeClients: wss.clients.size });
  });
  app.get("/api/rounds", (req, res) => {
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    res.setHeader("Surrogate-Control", "no-store");
    const statusParam = req.query.status;
    const limitParam = req.query.limit;
    let filtered = [...serverRounds];
    if (statusParam) {
      const allowedStatuses = statusParam.split(",").map((s) => s.trim().toLowerCase());
      filtered = filtered.filter(
        (r) => allowedStatuses.includes(String(r.status || "").toLowerCase())
      );
    }
    filtered.sort((a, b) => {
      const timeA = new Date(a.starts_at || a.openBetAt || a.drawAt).getTime();
      const timeB = new Date(b.starts_at || b.openBetAt || b.drawAt).getTime();
      if (timeA !== timeB) return timeA - timeB;
      return (a.order || a.roundNumber || 0) - (b.order || b.roundNumber || 0);
    });
    if (limitParam) {
      const limitNum = parseInt(limitParam, 10);
      if (!isNaN(limitNum) && limitNum > 0) {
        filtered = filtered.slice(0, limitNum);
      }
    }
    res.json({
      success: true,
      timestamp: Date.now(),
      total: filtered.length,
      data: filtered
    });
  });
  app.post("/api/rounds", (req, res) => {
    const roundData = req.body;
    if (!roundData || !roundData.id) {
      return res.status(400).json({ success: false, message: "ID de ronda requerido" });
    }
    const existingIdx = serverRounds.findIndex((r) => r.id === roundData.id);
    if (existingIdx >= 0) {
      serverRounds[existingIdx] = { ...serverRounds[existingIdx], ...roundData };
    } else {
      serverRounds = [roundData, ...serverRounds];
    }
    broadcastRealtimeEvent("new_round_created", { round: roundData });
    res.json({
      success: true,
      message: "Sorteo creado y emitido en tiempo real con \xE9xito",
      round: roundData
    });
  });
  app.put("/api/rounds/:id", (req, res) => {
    const { id } = req.params;
    const updates = req.body;
    const idx = serverRounds.findIndex((r) => r.id === id);
    if (idx < 0) {
      return res.status(404).json({ success: false, message: "Sorteo no encontrado" });
    }
    serverRounds[idx] = { ...serverRounds[idx], ...updates };
    const updated = serverRounds[idx];
    broadcastRealtimeEvent("round_updated", { round: updated });
    broadcastRealtimeEvent("postgres_changes", {
      event: "UPDATE",
      schema: "public",
      table: "rounds",
      new: updated,
      record: updated
    });
    res.json({
      success: true,
      message: "Sorteo actualizado correctamente",
      round: updated
    });
  });
  app.post("/api/rounds/:id/results", (req, res) => {
    const { id } = req.params;
    const {
      drawnFichas,
      winnersCount,
      totalPaidVes,
      resultSubmittedBy,
      resultSubmittedAt,
      updatedRound,
      updatedCards,
      userWinnings
    } = req.body;
    const idx = serverRounds.findIndex((r) => r.id === id);
    if (idx < 0) {
      return res.status(404).json({ success: false, message: "Sorteo no encontrado en base de datos central" });
    }
    const current = serverRounds[idx];
    const finalDrawn = Array.isArray(drawnFichas) ? drawnFichas : current.drawnFichas || [];
    const finalSubmittedAt = resultSubmittedAt || (/* @__PURE__ */ new Date()).toISOString();
    const finalSubmittedBy = resultSubmittedBy || "Super Admin";
    serverRounds[idx] = {
      ...current,
      ...updatedRound || {},
      id,
      status: "finished",
      drawnFichas: finalDrawn,
      resultLocked: true,
      winningCardsCount: typeof winnersCount === "number" ? winnersCount : updatedRound?.winningCardsCount || 0,
      totalPrizesPaidVes: typeof totalPaidVes === "number" ? totalPaidVes : updatedRound?.totalPrizesPaidVes || 0,
      resultSubmittedBy: finalSubmittedBy,
      resultSubmittedAt: finalSubmittedAt,
      updatedAt: finalSubmittedAt
    };
    const finalizedRound = serverRounds[idx];
    if (Array.isArray(updatedCards) && updatedCards.length > 0) {
      const cardMap = new Map(updatedCards.map((c) => [c.id, c]));
      serverCards = serverCards.map((c) => cardMap.get(c.id) || c);
      updatedCards.forEach((c) => {
        if (!serverCards.some((sc) => sc.id === c.id)) {
          serverCards.push(c);
        }
      });
    }
    if (userWinnings && typeof userWinnings === "object") {
      Object.entries(userWinnings).forEach(([userId, prizeAmount]) => {
        const amount = Number(prizeAmount) || 0;
        if (amount > 0) {
          const userIdx = serverUsers.findIndex((u) => String(u.id) === String(userId));
          if (userIdx >= 0) {
            const currentBal = Number(serverUsers[userIdx].availableBalance ?? serverUsers[userIdx].balanceVes ?? 0);
            const newBal = currentBal + amount;
            serverUsers[userIdx] = {
              ...serverUsers[userIdx],
              availableBalance: newBal,
              balanceVes: newBal,
              balance: newBal,
              saldo_disponible: newBal,
              totalWonVes: (Number(serverUsers[userIdx].totalWonVes) || 0) + amount
            };
            const updatedUser = serverUsers[userIdx];
            broadcastRealtimeEvent("postgres_changes", {
              event: "UPDATE",
              schema: "public",
              table: "users",
              new: updatedUser,
              record: updatedUser
            });
            broadcastRealtimeEvent("wallet_balance_updated", {
              userId,
              availableBalance: newBal,
              prizeWon: amount
            });
          }
        }
      });
    }
    broadcastRealtimeEvent("draw_result_published", {
      roundId: id,
      drawnFichas: finalDrawn,
      winnersCount: finalizedRound.winningCardsCount,
      totalPaidVes: finalizedRound.totalPrizesPaidVes,
      updatedRound: finalizedRound,
      updatedCards
    });
    broadcastRealtimeEvent("round_updated", { round: finalizedRound });
    broadcastRealtimeEvent("postgres_changes", {
      event: "UPDATE",
      schema: "public",
      table: "rounds",
      new: finalizedRound,
      record: finalizedRound
    });
    console.log(`\u{1F3B0} [OFICIAL] Resultado emitido para Sorteo ${id}: ${finalDrawn.length} figuras. Ganadores: ${finalizedRound.winningCardsCount}.`);
    res.json({
      success: true,
      message: "Resultado oficial publicado y distribuido a todos los clientes en tiempo real",
      round: finalizedRound
    });
  });
  app.get("/api/cards", (req, res) => {
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    const { roundId, userId } = req.query;
    let filtered = [...serverCards];
    if (roundId) {
      filtered = filtered.filter((c) => String(c.roundId) === String(roundId));
    }
    if (userId) {
      filtered = filtered.filter((c) => String(c.userId) === String(userId));
    }
    res.json({
      success: true,
      total: filtered.length,
      data: filtered
    });
  });
  app.post("/api/cards", (req, res) => {
    const cardsData = req.body;
    const cardsToAdd = Array.isArray(cardsData) ? cardsData : cardsData?.cards || (cardsData?.id ? [cardsData] : []);
    if (cardsToAdd.length > 0) {
      const newCardIds = new Set(cardsToAdd.map((c) => c.id));
      serverCards = [...cardsToAdd, ...serverCards.filter((c) => !newCardIds.has(c.id))];
      broadcastRealtimeEvent("postgres_changes", {
        event: "INSERT",
        schema: "public",
        table: "cards",
        new: cardsToAdd
      });
      broadcastRealtimeEvent("cards_purchased", { cards: cardsToAdd });
    }
    res.json({
      success: true,
      message: `${cardsToAdd.length} cartones sincronizados en servidor`,
      data: serverCards
    });
  });
  app.post("/api/sync-cards", (req, res) => {
    const { cards } = req.body;
    if (Array.isArray(cards) && cards.length > 0) {
      const cardMap = new Map(cards.map((c) => [c.id, c]));
      serverCards = serverCards.map((c) => cardMap.get(c.id) || c);
      cards.forEach((c) => {
        if (!serverCards.some((sc) => sc.id === c.id)) {
          serverCards.push(c);
        }
      });
    }
    res.json({ success: true, count: serverCards.length });
  });
  app.post("/api/sync-rounds", (req, res) => {
    const { rounds } = req.body;
    if (Array.isArray(rounds) && rounds.length > 0) {
      if (serverRounds.every((r) => r.totalCardsSold === 0) && rounds.some((r) => r.totalCardsSold > 0)) {
        res.json({ success: true, count: serverRounds.length, blocked: true });
        return;
      }
      const m = new Map(rounds.map((r) => [r.id, r]));
      serverRounds = serverRounds.map((r) => m.get(r.id) || r);
      rounds.forEach((r) => {
        if (!serverRounds.some((s) => s.id === r.id)) serverRounds.push(r);
      });
    }
    res.json({ success: true, count: serverRounds.length });
  });
  app.post("/api/reset-fabrica-total", (req, res) => {
    serverRecharges = [];
    serverWithdrawals = [];
    serverRounds = serverRounds.map((r) => ({ ...r, totalCardsSold: 0, totalPrizesPaidVes: 0, winningCardsCount: 0, drawnFichas: [], resultLocked: false, jackpotVes: 0, status: r.order === 1 ? "open" : "scheduled" }));
    console.log("\u2705 RESET FABRICA");
    res.json({ success: true });
  });
  app.get("/api/recharges", (req, res) => {
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    const statusParam = req.query.status;
    let filtered = [...serverRecharges];
    if (statusParam) {
      const allowed = statusParam.split(",").map((s) => s.trim().toLowerCase());
      filtered = filtered.filter((r) => allowed.includes(String(r.status || "").toLowerCase()));
    }
    res.json({
      success: true,
      timestamp: Date.now(),
      total: filtered.length,
      data: filtered
    });
  });
  app.post("/api/recharges", (req, res) => {
    const recharge = req.body;
    if (!recharge || !recharge.id) {
      return res.status(400).json({ success: false, message: "Datos de recarga inv\xE1lidos" });
    }
    const existingIdx = serverRecharges.findIndex((r) => r.id === recharge.id);
    if (existingIdx >= 0) {
      serverRecharges[existingIdx] = { ...serverRecharges[existingIdx], ...recharge };
    } else {
      serverRecharges = [recharge, ...serverRecharges];
    }
    broadcastRealtimeEvent("postgres_changes", {
      event: existingIdx >= 0 ? "UPDATE" : "INSERT",
      schema: "public",
      table: "recharges",
      new: recharge,
      record: recharge
    });
    broadcastRealtimeEvent("recharge_created", { recharge });
    res.json({
      success: true,
      message: "Comprobante recibido y transmitido en tiempo real",
      data: recharge
    });
  });
  app.patch("/api/recharges/:id", (req, res) => {
    const { id } = req.params;
    const updates = req.body;
    const idx = serverRecharges.findIndex((r) => String(r.id) === String(id));
    if (idx < 0) {
      return res.status(404).json({ success: false, message: "Recarga no encontrada" });
    }
    const previousStatus = String(serverRecharges[idx].status || "").toLowerCase();
    const newStatusLower = String(updates.status || "").toLowerCase();
    const isApproving = (newStatusLower === "approved" || newStatusLower === "aprobado") && previousStatus !== "approved";
    serverRecharges[idx] = {
      ...serverRecharges[idx],
      ...updates,
      status: isApproving ? "approved" : updates.status,
      confirmedBankArrival: isApproving ? true : serverRecharges[idx].confirmedBankArrival
    };
    const updated = serverRecharges[idx];
    let updatedUser = null;
    if (isApproving) {
      const amountToAdd = Number(updated.amountVes) || 0;
      const targetUserId = updated.userId;
      const userIdx = serverUsers.findIndex(
        (u) => String(u.id) === String(targetUserId) || updated.payerDocumentId && u.documentId && String(u.documentId).toUpperCase() === String(updated.payerDocumentId).toUpperCase() || updated.userPhone && u.phone === updated.userPhone
      );
      if (userIdx >= 0) {
        const currentUser = serverUsers[userIdx];
        const currentAvailable = Number(currentUser.availableBalance ?? currentUser.balanceVes ?? 0);
        const newAvailable = currentAvailable + amountToAdd;
        const currentPending = Number(currentUser.pendingBalance) || 0;
        const currentSaldoPendiente = Number(currentUser.saldo_pendiente) || 0;
        serverUsers[userIdx] = {
          ...currentUser,
          availableBalance: newAvailable,
          balanceVes: newAvailable,
          balance: newAvailable,
          saldo_disponible: newAvailable,
          pendingBalance: Math.max(0, currentPending - amountToAdd),
          saldo_pendiente: Math.max(0, currentSaldoPendiente - amountToAdd)
        };
        updatedUser = serverUsers[userIdx];
        broadcastRealtimeEvent("postgres_changes", {
          event: "UPDATE",
          schema: "public",
          table: "users",
          new: updatedUser,
          record: updatedUser
        });
        broadcastRealtimeEvent("user_balance_updated", {
          userId: updatedUser.id,
          availableBalance: updatedUser.availableBalance,
          user: updatedUser
        });
      }
    }
    broadcastRealtimeEvent("postgres_changes", {
      event: "UPDATE",
      schema: "public",
      table: "recharges",
      new: updated,
      record: updated
    });
    broadcastRealtimeEvent("recharge_updated", { recharge: updated, user: updatedUser });
    if (isApproving) {
      broadcastRealtimeEvent("recharge_approved", { recharge: updated, user: updatedUser });
    }
    res.json({ success: true, data: updated, user: updatedUser });
  });
  const handleApproveRechargeController = (req, res) => {
    const { id } = req.params;
    const { operatorIdentifier } = req.body || {};
    const idx = serverRecharges.findIndex((r) => String(r.id) === String(id));
    if (idx < 0) {
      return res.status(404).json({ success: false, message: "Recarga no encontrada" });
    }
    const rec = serverRecharges[idx];
    const amountToAdd = Number(rec.amountVes) || 0;
    const processedAt = (/* @__PURE__ */ new Date()).toISOString();
    serverRecharges[idx] = {
      ...rec,
      status: "approved",
      confirmedBankArrival: true,
      processedAt,
      processedBy: operatorIdentifier || "Super Admin (Auditor\xEDa)"
    };
    const updatedRecharge = serverRecharges[idx];
    let updatedUser = null;
    const userIdx = serverUsers.findIndex(
      (u) => String(u.id) === String(rec.userId) || rec.payerDocumentId && u.documentId && String(u.documentId).toUpperCase() === String(rec.payerDocumentId).toUpperCase() || rec.userPhone && u.phone === rec.userPhone
    );
    if (userIdx >= 0) {
      const currentUser = serverUsers[userIdx];
      const currentAvailable = Number(currentUser.availableBalance ?? currentUser.balanceVes ?? 0);
      const newAvailable = currentAvailable + amountToAdd;
      const currentPending = Number(currentUser.pendingBalance) || 0;
      const currentSaldoPendiente = Number(currentUser.saldo_pendiente) || 0;
      serverUsers[userIdx] = {
        ...currentUser,
        availableBalance: newAvailable,
        balanceVes: newAvailable,
        balance: newAvailable,
        saldo_disponible: newAvailable,
        pendingBalance: Math.max(0, currentPending - amountToAdd),
        saldo_pendiente: Math.max(0, currentSaldoPendiente - amountToAdd)
      };
      updatedUser = serverUsers[userIdx];
      broadcastRealtimeEvent("postgres_changes", {
        event: "UPDATE",
        schema: "public",
        table: "users",
        new: updatedUser,
        record: updatedUser
      });
      broadcastRealtimeEvent("user_balance_updated", {
        userId: updatedUser.id,
        availableBalance: updatedUser.availableBalance,
        user: updatedUser
      });
    }
    broadcastRealtimeEvent("postgres_changes", {
      event: "UPDATE",
      schema: "public",
      table: "recharges",
      new: updatedRecharge,
      record: updatedRecharge
    });
    broadcastRealtimeEvent("recharge_approved", { recharge: updatedRecharge, user: updatedUser });
    broadcastRealtimeEvent("recharge_updated", { recharge: updatedRecharge, user: updatedUser });
    res.json({
      success: true,
      message: `Recarga aprobada y ${amountToAdd} Bs. acreditados instant\xE1neamente al Saldo Disponible del jugador.`,
      recharge: updatedRecharge,
      user: updatedUser
    });
  };
  app.post("/api/recharges/:id/approve", handleApproveRechargeController);
  app.post("/api/admin/recharges/:id/approve", handleApproveRechargeController);
  app.post("/api/sync-recharges", (req, res) => {
    const { recharges } = req.body;
    if (Array.isArray(recharges) && recharges.length > 0) {
      if (serverRecharges.length === 0) {
        res.json({ success: true, count: 0, blocked: true });
        return;
      }
      const m = new Map(recharges.map((r) => [r.id, r]));
      serverRecharges = serverRecharges.map((r) => m.get(r.id) || r);
      recharges.forEach((r) => {
        if (!serverRecharges.some((s) => s.id === r.id)) serverRecharges.push(r);
      });
    }
    res.json({ success: true, count: serverRecharges.length });
  });
  app.get("/api/withdrawals", (req, res) => {
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    const statusParam = req.query.status;
    const userIdParam = req.query.userId;
    let filtered = [...serverWithdrawals];
    if (statusParam) {
      const allowed = statusParam.split(",").map((s) => s.trim().toLowerCase());
      filtered = filtered.filter((w) => allowed.includes(String(w.status || "").toLowerCase()));
    }
    if (userIdParam) {
      filtered = filtered.filter((w) => w.userId === userIdParam);
    }
    res.json({
      success: true,
      timestamp: Date.now(),
      total: filtered.length,
      data: filtered
    });
  });
  app.post("/api/withdrawals", (req, res) => {
    const withdrawal = req.body;
    if (!withdrawal || !withdrawal.id) {
      return res.status(400).json({ success: false, message: "Datos de retiro inv\xE1lidos" });
    }
    const amountToLock = Number(withdrawal.amountVes) || 0;
    if (amountToLock < 100) {
      return res.status(400).json({ success: false, message: "El monto m\xEDnimo de retiro es de 100 Bs." });
    }
    const existingIdx = serverWithdrawals.findIndex((w) => w.id === withdrawal.id);
    if (existingIdx >= 0) {
      serverWithdrawals[existingIdx] = { ...serverWithdrawals[existingIdx], ...withdrawal };
    } else {
      serverWithdrawals = [withdrawal, ...serverWithdrawals];
    }
    const userIdx = serverUsers.findIndex((u) => u.id === withdrawal.userId);
    let updatedUser = null;
    if (userIdx >= 0 && existingIdx < 0) {
      serverUsers[userIdx].availableBalance = Math.max(0, (Number(serverUsers[userIdx].availableBalance) || 0) - amountToLock);
      serverUsers[userIdx].lockedBalance = (Number(serverUsers[userIdx].lockedBalance) || 0) + amountToLock;
      updatedUser = serverUsers[userIdx];
      broadcastRealtimeEvent("postgres_changes", {
        event: "UPDATE",
        schema: "public",
        table: "users",
        new: updatedUser,
        record: updatedUser
      });
    }
    broadcastRealtimeEvent("postgres_changes", {
      event: existingIdx >= 0 ? "UPDATE" : "INSERT",
      schema: "public",
      table: "withdrawals",
      new: withdrawal,
      record: withdrawal
    });
    broadcastRealtimeEvent("withdrawal_created", { withdrawal, user: updatedUser });
    res.json({
      success: true,
      message: "Solicitud de retiro registrada y transmitida en tiempo real",
      data: withdrawal,
      user: updatedUser
    });
  });
  app.patch("/api/withdrawals/:id", (req, res) => {
    const { id } = req.params;
    const updates = req.body;
    const idx = serverWithdrawals.findIndex((w) => String(w.id) === String(id));
    if (idx < 0) {
      return res.status(404).json({ success: false, message: "Solicitud de retiro no encontrada" });
    }
    const previousStatus = String(serverWithdrawals[idx].status || "").toLowerCase();
    const newStatusLower = String(updates.status || "").toLowerCase();
    const isApproving = (newStatusLower === "completed" || newStatusLower === "approved") && previousStatus !== "completed" && previousStatus !== "approved";
    serverWithdrawals[idx] = { ...serverWithdrawals[idx], ...updates };
    const updated = serverWithdrawals[idx];
    let updatedUser = null;
    if (isApproving) {
      const amount = Number(updated.amountVes) || 0;
      const userIdx = serverUsers.findIndex(
        (u) => String(u.id) === String(updated.userId) || updated.documentId && u.documentId && String(u.documentId).toUpperCase() === String(updated.documentId).toUpperCase() || updated.userPhone && u.phone === updated.userPhone
      );
      if (userIdx >= 0) {
        const currentUser = serverUsers[userIdx];
        const currentAvailable = Number(currentUser.availableBalance ?? currentUser.balanceVes ?? 0);
        const currentLocked = Number(currentUser.lockedBalance) || 0;
        let newAvailable = currentAvailable;
        let newLocked = currentLocked;
        if (currentLocked >= amount) {
          newLocked = Math.max(0, currentLocked - amount);
        } else {
          const remaining = amount - currentLocked;
          newLocked = 0;
          newAvailable = Math.max(0, currentAvailable - remaining);
        }
        serverUsers[userIdx] = {
          ...currentUser,
          availableBalance: newAvailable,
          balanceVes: newAvailable,
          balance: newAvailable,
          saldo_disponible: newAvailable,
          lockedBalance: newLocked
        };
        updatedUser = serverUsers[userIdx];
        broadcastRealtimeEvent("postgres_changes", {
          event: "UPDATE",
          schema: "public",
          table: "users",
          new: updatedUser,
          record: updatedUser
        });
      }
    }
    broadcastRealtimeEvent("postgres_changes", {
      event: "UPDATE",
      schema: "public",
      table: "withdrawals",
      new: updated,
      record: updated
    });
    broadcastRealtimeEvent("withdrawal_updated", { withdrawal: updated, user: updatedUser });
    if (isApproving) {
      broadcastRealtimeEvent("withdrawal_completed", { withdrawal: updated, user: updatedUser });
      broadcastRealtimeEvent("withdrawal_approved", { withdrawal: updated, user: updatedUser });
    }
    res.json({ success: true, data: updated, user: updatedUser });
  });
  const handleApproveWithdrawalEndpoint = (req, res) => {
    const { id } = req.params;
    const { operatorIdentifier, operatorRole } = req.body || {};
    const effectiveRole = String(operatorRole || operatorIdentifier || "").trim();
    const authorizedRoles = ["Super Admin", "Operador Financiero", "superadmin", "operador financiero", "super admin"];
    const isAuthorized = effectiveRole ? authorizedRoles.some((r) => r.toLowerCase() === effectiveRole.toLowerCase()) : true;
    if (effectiveRole && !isAuthorized) {
      return res.status(403).json({
        success: false,
        message: "Acceso Denegado: Solo usuarios con rol Superadministrador u Operador Financiero pueden procesar pagos de retiros."
      });
    }
    const idx = serverWithdrawals.findIndex((w) => String(w.id) === String(id));
    if (idx < 0) {
      return res.status(404).json({ success: false, message: "Solicitud de retiro no encontrada" });
    }
    const wth = serverWithdrawals[idx];
    const amount = Number(wth.amountVes) || 0;
    const processedAt = (/* @__PURE__ */ new Date()).toISOString();
    serverWithdrawals[idx] = {
      ...wth,
      status: "completed",
      confirmedBankArrival: true,
      processedAt,
      processedBy: effectiveRole || "Super Admin (Liquidaci\xF3n)"
    };
    const updatedWithdrawal = serverWithdrawals[idx];
    let updatedUser = null;
    const userIdx = serverUsers.findIndex(
      (u) => String(u.id) === String(wth.userId) || wth.documentId && u.documentId && String(u.documentId).toUpperCase() === String(wth.documentId).toUpperCase() || wth.userPhone && u.phone === wth.userPhone
    );
    if (userIdx >= 0) {
      const currentUser = serverUsers[userIdx];
      const currentAvailable = Number(currentUser.availableBalance ?? currentUser.balanceVes ?? 0);
      const currentLocked = Number(currentUser.lockedBalance) || 0;
      let newAvailable = currentAvailable;
      let newLocked = currentLocked;
      if (currentLocked >= amount) {
        newLocked = Math.max(0, currentLocked - amount);
      } else {
        const remainingToDebit = amount - currentLocked;
        newLocked = 0;
        newAvailable = Math.max(0, currentAvailable - remainingToDebit);
      }
      serverUsers[userIdx] = {
        ...currentUser,
        availableBalance: newAvailable,
        balanceVes: newAvailable,
        balance: newAvailable,
        saldo_disponible: newAvailable,
        lockedBalance: newLocked
      };
      updatedUser = serverUsers[userIdx];
      broadcastRealtimeEvent("postgres_changes", {
        event: "UPDATE",
        schema: "public",
        table: "users",
        new: updatedUser,
        record: updatedUser
      });
    } else {
      console.warn(`Alerta: Retiro ${id} liquidado, pero no se encontr\xF3 al usuario para actualizar saldo.`);
    }
    broadcastRealtimeEvent("postgres_changes", {
      event: "UPDATE",
      schema: "public",
      table: "withdrawals",
      new: updatedWithdrawal,
      record: updatedWithdrawal
    });
    broadcastRealtimeEvent("withdrawal_completed", { withdrawal: updatedWithdrawal, user: updatedUser });
    broadcastRealtimeEvent("withdrawal_approved", { withdrawal: updatedWithdrawal, user: updatedUser });
    res.json({
      success: true,
      message: `Retiro de ${amount} Bs. aprobado, liquidado y descontado at\xF3micamente del saldo del jugador.`,
      withdrawal: updatedWithdrawal,
      user: updatedUser
    });
  };
  app.post("/api/withdrawals/:id/complete", handleApproveWithdrawalEndpoint);
  app.post("/api/withdrawals/:id/approve", handleApproveWithdrawalEndpoint);
  app.post("/api/admin/withdrawals/:id/complete", handleApproveWithdrawalEndpoint);
  app.post("/api/admin/withdrawals/:id/approve", handleApproveWithdrawalEndpoint);
  app.post("/api/withdrawals/:id/reject", (req, res) => {
    const { id } = req.params;
    const { reason, operatorIdentifier, operatorRole } = req.body || {};
    const effectiveRole = String(operatorRole || operatorIdentifier || "").trim();
    const authorizedRoles = ["Super Admin", "Operador Financiero", "superadmin", "operador financiero", "super admin"];
    const isAuthorized = effectiveRole ? authorizedRoles.some((r) => r.toLowerCase() === effectiveRole.toLowerCase()) : true;
    if (effectiveRole && !isAuthorized) {
      return res.status(403).json({
        success: false,
        message: "Acceso Denegado: Solo usuarios con rol Superadministrador u Operador Financiero pueden procesar o rechazar retiros."
      });
    }
    const idx = serverWithdrawals.findIndex((w) => w.id === id);
    if (idx < 0) {
      return res.status(404).json({ success: false, message: "Solicitud de retiro no encontrada" });
    }
    const wth = serverWithdrawals[idx];
    const amount = Number(wth.amountVes) || 0;
    const processedAt = (/* @__PURE__ */ new Date()).toISOString();
    serverWithdrawals[idx] = {
      ...wth,
      status: "rejected",
      rejectionReason: reason || "Datos de cuenta err\xF3neos o inv\xE1lidos.",
      processedAt,
      processedBy: effectiveRole || "Operador Financiero"
    };
    const updatedWithdrawal = serverWithdrawals[idx];
    let updatedUser = null;
    const userIdx = serverUsers.findIndex((u) => u.id === wth.userId);
    if (userIdx >= 0) {
      serverUsers[userIdx].lockedBalance = Math.max(0, (Number(serverUsers[userIdx].lockedBalance) || 0) - amount);
      serverUsers[userIdx].availableBalance = (Number(serverUsers[userIdx].availableBalance) || 0) + amount;
      updatedUser = serverUsers[userIdx];
      broadcastRealtimeEvent("postgres_changes", {
        event: "UPDATE",
        schema: "public",
        table: "users",
        new: updatedUser,
        record: updatedUser
      });
    }
    broadcastRealtimeEvent("postgres_changes", {
      event: "UPDATE",
      schema: "public",
      table: "withdrawals",
      new: updatedWithdrawal,
      record: updatedWithdrawal
    });
    broadcastRealtimeEvent("withdrawal_rejected", { withdrawal: updatedWithdrawal, user: updatedUser });
    res.json({
      success: true,
      message: `Retiro rechazado. Los fondos (${amount} Bs.) han sido devueltos al saldo disponible del usuario.`,
      withdrawal: updatedWithdrawal,
      user: updatedUser
    });
  });
  app.post("/api/sync-withdrawals", (req, res) => {
    const { withdrawals } = req.body;
    if (Array.isArray(withdrawals) && withdrawals.length > 0) {
      if (serverWithdrawals.length === 0) {
        serverWithdrawals = [...withdrawals];
        res.json({ success: true, count: serverWithdrawals.length });
        return;
      }
      const m = new Map(withdrawals.map((w) => [w.id, w]));
      serverWithdrawals = serverWithdrawals.map((w) => m.get(w.id) || w);
      withdrawals.forEach((w) => {
        if (!serverWithdrawals.some((s) => s.id === w.id)) serverWithdrawals.push(w);
      });
    }
    res.json({ success: true, count: serverWithdrawals.length });
  });
  const handleGetUsers = (req, res) => {
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    res.json({
      success: true,
      timestamp: Date.now(),
      total: serverUsers.length,
      data: serverUsers
    });
  };
  app.get("/api/users", handleGetUsers);
  app.get("/api/players", handleGetUsers);
  const handlePostUser = (req, res) => {
    const userData = req.body;
    if (!userData) {
      return res.status(400).json({ success: false, message: "Datos de usuario requeridos" });
    }
    const cleanDoc = (userData.documentId || userData.cedula || "").trim().toUpperCase();
    const fullName = (userData.name || `${userData.firstName || ""} ${userData.lastName || ""}`).trim() || "Nuevo Jugador";
    const userId = userData.id || `usr-${Date.now()}`;
    const newUserRecord = {
      id: userId,
      name: fullName,
      firstName: (userData.firstName || fullName.split(" ")[0] || "").trim(),
      lastName: (userData.lastName || fullName.split(" ").slice(1).join(" ") || "").trim(),
      email: (userData.email || "").trim().toLowerCase(),
      password: userData.password || "123456",
      documentId: cleanDoc,
      phone: (userData.phone || userData.telefono || "0412-0000000").trim(),
      birthDate: userData.birthDate || "2000-01-01",
      country: "Venezuela",
      role: userData.role || "Player",
      status: userData.status || "active",
      availableBalance: userData.availableBalance !== void 0 ? userData.availableBalance : 0,
      pendingBalance: userData.pendingBalance || 0,
      lockedBalance: userData.lockedBalance || 0,
      totalWonVes: userData.totalWonVes || 0,
      totalSpentVes: userData.totalSpentVes || 0,
      createdAt: userData.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
      kycStatus: userData.kycStatus || "Aprobado",
      kycVerifiedAt: userData.kycVerifiedAt || (/* @__PURE__ */ new Date()).toISOString(),
      kycFrontUrl: userData.kycFrontUrl || userData.foto || "",
      kycBackUrl: userData.kycBackUrl || "",
      twoFactorEnabled: !!userData.twoFactorEnabled,
      twoFactorMethod: userData.twoFactorMethod || "none",
      withdrawalMethods: userData.withdrawalMethods || [],
      foto: userData.foto || userData.kycFrontUrl || ""
    };
    const existingIdx = serverUsers.findIndex(
      (u) => u.id === userId || cleanDoc && u.documentId && u.documentId.toUpperCase() === cleanDoc
    );
    if (existingIdx >= 0) {
      serverUsers[existingIdx] = {
        ...serverUsers[existingIdx],
        ...newUserRecord,
        password: userData.password || serverUsers[existingIdx].password || "123456"
      };
    } else {
      serverUsers = [newUserRecord, ...serverUsers];
    }
    broadcastRealtimeEvent("postgres_changes", {
      event: existingIdx >= 0 ? "UPDATE" : "INSERT",
      schema: "public",
      table: "users",
      new: existingIdx >= 0 ? serverUsers[existingIdx] : newUserRecord,
      record: existingIdx >= 0 ? serverUsers[existingIdx] : newUserRecord
    });
    broadcastRealtimeEvent("postgres_changes", {
      event: existingIdx >= 0 ? "UPDATE" : "INSERT",
      schema: "public",
      table: "jugadores",
      new: existingIdx >= 0 ? serverUsers[existingIdx] : newUserRecord,
      record: existingIdx >= 0 ? serverUsers[existingIdx] : newUserRecord
    });
    broadcastRealtimeEvent("user_registered", { user: existingIdx >= 0 ? serverUsers[existingIdx] : newUserRecord });
    broadcastRealtimeEvent("player_registered", { player: existingIdx >= 0 ? serverUsers[existingIdx] : newUserRecord });
    res.status(201).json({
      success: true,
      message: "\xA1Usuario registrado y transmitido al panel administrativo en tiempo real con \xE9xito!",
      data: existingIdx >= 0 ? serverUsers[existingIdx] : newUserRecord
    });
  };
  app.post("/api/users", handlePostUser);
  app.post("/api/players", handlePostUser);
  app.patch("/api/users/:id", (req, res) => {
    const { id } = req.params;
    const updates = req.body;
    const idx = serverUsers.findIndex((u) => u.id === id);
    if (idx === -1) {
      return res.status(404).json({ success: false, message: "Usuario no encontrado" });
    }
    serverUsers[idx] = { ...serverUsers[idx], ...updates };
    broadcastRealtimeEvent("postgres_changes", {
      event: "UPDATE",
      schema: "public",
      table: "users",
      new: serverUsers[idx],
      record: serverUsers[idx]
    });
    res.json({ success: true, message: "Usuario actualizado correctamente", data: serverUsers[idx] });
  });
  app.post("/api/users/:id/change-password", (req, res) => {
    const { id } = req.params;
    const { currentPassword, newPassword } = req.body;
    if (!newPassword || newPassword.trim().length < 6) {
      return res.status(400).json({ success: false, message: "La nueva contrase\xF1a debe tener al menos 6 caracteres" });
    }
    const idx = serverUsers.findIndex((u) => u.id === id);
    if (idx === -1) {
      return res.status(404).json({ success: false, message: "Usuario no encontrado" });
    }
    const user = serverUsers[idx];
    if (currentPassword && user.password && user.password !== currentPassword.trim()) {
      return res.status(400).json({ success: false, message: "La contrase\xF1a actual ingresada es incorrecta" });
    }
    serverUsers[idx] = {
      ...user,
      password: newPassword.trim(),
      failedLoginAttempts: 0,
      lockoutUntil: null
    };
    broadcastRealtimeEvent("postgres_changes", {
      event: "UPDATE",
      schema: "public",
      table: "users",
      new: serverUsers[idx],
      record: serverUsers[idx]
    });
    res.json({ success: true, message: "\xA1Contrase\xF1a actualizada con \xE9xito!" });
  });
  app.post("/api/reset-password", (req, res) => {
    const { identifier, newPassword } = req.body;
    if (!identifier || !newPassword || newPassword.trim().length < 6) {
      return res.status(400).json({ success: false, message: "Identificador y nueva contrase\xF1a v\xE1lida (m\xEDnimo 6 caracteres) requeridos" });
    }
    const clean = identifier.trim().toLowerCase();
    let updatedCount = 0;
    const userIdx = serverUsers.findIndex(
      (u) => u.email && u.email.toLowerCase() === clean || u.name.toLowerCase() === clean || u.documentId && u.documentId.toLowerCase() === clean || u.phone === clean
    );
    if (userIdx >= 0) {
      serverUsers[userIdx] = {
        ...serverUsers[userIdx],
        password: newPassword.trim(),
        failedLoginAttempts: 0,
        lockoutUntil: null
      };
      updatedCount++;
      broadcastRealtimeEvent("postgres_changes", {
        event: "UPDATE",
        schema: "public",
        table: "users",
        new: serverUsers[userIdx],
        record: serverUsers[userIdx]
      });
    }
    const credIdx = serverCredentials.findIndex(
      (c) => c.username.toLowerCase() === clean || c.username.toLowerCase() === clean.split("@")[0]
    );
    if (credIdx >= 0) {
      serverCredentials[credIdx] = {
        ...serverCredentials[credIdx],
        password: newPassword.trim()
      };
      updatedCount++;
      broadcastRealtimeEvent("credentials_updated", { credentials: serverCredentials });
    }
    if (updatedCount === 0) {
      return res.status(404).json({ success: false, message: "No se encontr\xF3 ninguna cuenta asociada a los datos proporcionados" });
    }
    res.json({ success: true, message: "\xA1Contrase\xF1a restablecida exitosamente en el servidor central!" });
  });
  app.get("/api/credentials", (req, res) => {
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0");
    res.json({ success: true, data: serverCredentials });
  });
  app.post("/api/credentials", (req, res) => {
    const cred = req.body;
    if (!cred || !cred.username || !cred.password) {
      return res.status(400).json({ success: false, message: "Usuario y contrase\xF1a requeridos" });
    }
    const newCred = {
      id: cred.id || `cred-${Date.now()}`,
      displayName: cred.displayName || cred.username,
      username: cred.username.trim(),
      role: cred.role || "Super Admin",
      status: cred.status || "active",
      createdAt: cred.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
      password: cred.password.trim()
    };
    const existingIdx = serverCredentials.findIndex((c) => c.username.toLowerCase() === newCred.username.toLowerCase());
    if (existingIdx >= 0) {
      serverCredentials[existingIdx] = { ...serverCredentials[existingIdx], ...newCred };
    } else {
      serverCredentials = [newCred, ...serverCredentials];
    }
    broadcastRealtimeEvent("credentials_updated", { credentials: serverCredentials });
    res.status(201).json({ success: true, message: "Credencial de operador guardada exitosamente", data: newCred });
  });
  app.put("/api/credentials/:id", (req, res) => {
    const { id } = req.params;
    const updates = req.body;
    const idx = serverCredentials.findIndex((c) => c.id === id || c.username.toLowerCase() === (updates.username || "").toLowerCase());
    if (idx === -1) {
      return res.status(404).json({ success: false, message: "Credencial no encontrada" });
    }
    serverCredentials[idx] = {
      ...serverCredentials[idx],
      ...updates,
      password: updates.password ? updates.password.trim() : serverCredentials[idx].password
    };
    broadcastRealtimeEvent("credentials_updated", { credentials: serverCredentials });
    res.json({ success: true, message: "Credencial actualizada con \xE9xito", data: serverCredentials[idx] });
  });
  app.delete("/api/credentials/:id", (req, res) => {
    const { id } = req.params;
    serverCredentials = serverCredentials.filter((c) => c.id !== id);
    broadcastRealtimeEvent("credentials_updated", { credentials: serverCredentials });
    res.json({ success: true, message: "Credencial eliminada" });
  });
  app.post("/api/sync-credentials", (req, res) => {
    const { credentials } = req.body;
    if (Array.isArray(credentials) && credentials.length > 0) {
      const m = new Map(credentials.map((c) => [c.id, c]));
      serverCredentials = serverCredentials.map((c) => m.get(c.id) || c);
      credentials.forEach((c) => {
        if (!serverCredentials.some((s) => s.id === c.id)) serverCredentials.push(c);
      });
    }
    res.json({ success: true, count: serverCredentials.length });
  });
  app.post("/api/sync-users", (req, res) => {
    const { users } = req.body;
    if (Array.isArray(users) && users.length > 0) {
      const m = new Map(users.map((u) => [u.id, u]));
      serverUsers = serverUsers.map((u) => {
        const incoming = m.get(u.id);
        return incoming ? { ...u, ...incoming, password: incoming.password || u.password } : u;
      });
      users.forEach((u) => {
        if (!serverUsers.some((s) => s.id === u.id)) serverUsers.push(u);
      });
    }
    res.json({ success: true, count: serverUsers.length });
  });
  app.get("/dist-production.zip", (req, res) => {
    const zipPath = import_path.default.join(process.cwd(), "dist-production.zip");
    if (import_fs.default.existsSync(zipPath)) {
      res.download(zipPath, "dist-production.zip");
    } else {
      const publicZip = import_path.default.join(process.cwd(), "public", "dist-production.zip");
      if (import_fs.default.existsSync(publicZip)) {
        res.download(publicZip, "dist-production.zip");
      } else {
        res.status(404).send("ZIP no encontrado");
      }
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  server.listen(PORT, "0.0.0.0", () => {
    console.log(`[Server] SuperMillonario backend running on http://0.0.0.0:${PORT}`);
    console.log(`[Server] Realtime WebSocket active at ws://0.0.0.0:${PORT}/ws`);
  });
}
startServer().catch((err) => {
  console.error("[Server] Fatal startup error:", err);
});
//# sourceMappingURL=server.cjs.map
